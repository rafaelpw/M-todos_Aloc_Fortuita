#See Function GenW in "gen_functions"

pureRandom.Gr = function(x, num=1, nv) {
  
  n = nrow(x)  # N of rows
  m = ncol(x)  # N of Columns
  ng = length(nv)  # N of groups  
  

  W.temp = as.vector(GenW(nv))
  
  # no time controling
  rtime = 1

  
  # Inverse of cholesky factor of covariance of x
  invcholx = inverseCholCov(x)   # Caution: in R, chol(X) returns an upper triangular matrix
  z = as.matrix(x) %*% invcholx
  
  Anv<-matrix(0,nrow=nrow(z)*ng,ncol=ncol(z)*ng)
  for(i in 1:ng){
    Anv[((i-1)*nrow(z)+1):(nrow(z)*i),((i-1)*ncol(z)+1):(ncol(z)*i)]<-z/nv[i]
  }
  Anv<-t(Anv)
  
  S = rep(apply(z,2,sum)/n,ng) #Vectors of means of z, repeated ng times

  Stats = foreach(ids=1:num, .combine=cbind, .multicombine=TRUE, .inorder=FALSE) %dopar% {
    W.rand = as.vector(GenW(nv))
    dmeans = Anv %*% W.rand - S
    randD = calc.dist(dmeans, normdis, gamma1, gamma2)
    
    # MatrAloc is an auxiliary vector to hold the allocation vectors, processing times and distances. 
    # Each column corresponds to a time limit (secs) and the rows are organized as follows:
    #   1..n : binary allocations (0=control group, 1=treatment group)
    #   n+1 : total processing time
    #   n+2 : minimal distance (according to the norm specified by normdis string)
    #   n+3 : norm L1 distance
    #   n+4 : norm L2 distance
    #   n+5 : norm Linf distance
    #   n+6 : hybrid norm distance
    MatrAloc = matrix(
      c(W.rand, rtime, randD, 
        calc.dist(dmeans, normdis='1', gamma1, gamma2), calc.dist(dmeans, normdis='2', gamma1, gamma2),
        calc.dist(dmeans, normdis='I', gamma1, gamma2), calc.dist(dmeans, normdis='1I', gamma1, gamma2)),
      ncol=1)
    
    MatrAloc
  }  # foreach


  if (num==1) Stats = matrix(Stats, ncol=1)
  
  W = list()
  times = list()
  dists = list()
  distsL1 = list()
  distsL2 = list()
  distsLI = list()
  distsL1I = list()

  #browser()
  
  W[[1]] = Stats[1:(n*ng),]
  times[[1]] = Stats[(n*ng)+1,]
  dists[[1]] = Stats[(n*ng)+2,]
  distsL1[[1]] = Stats[(n*ng)+3,]
  distsL2[[1]] = Stats[(n*ng)+4,]
  distsLI[[1]] = Stats[(n*ng)+5,]
  distsL1I[[1]] = Stats[(n*ng)+6,]

  return(list(Stats=Stats, W=W, times=times, dists=dists, distsL1=distsL1, distsL2=distsL2, 
              distsLI=distsLI, distsL1I=distsL1I))
}



