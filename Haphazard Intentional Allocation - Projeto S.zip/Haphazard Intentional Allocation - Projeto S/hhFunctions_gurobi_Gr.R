###################
#
# Haphazard
#
#

require(gurobi)

source('MultiCore.R')
source('rrFunctions_Gr.R')

#
#  lambda: noise weight (0 < lambda < 1)
#  ma: number of columns of noise matrix
#  num: number of allocations
#  mipgap: relative gap between current and threshold distance
#  normdis: distance norm: '1' (Manhattan), '2' (Mahalanobis), 'I' (infinite, Max), 
#                          '1I' (0-Inf norm: norm1 + sqrt(m)*norm_inf)  
#  gamma1, gamma2: parameter in [0,1] for the one-infinity norm:
#                  one-inf norm = gamma1 * norm1 + gamma2 * sqrt(m) * norminf
#  a: distance threshold
#
hapsamplingGurobi_Gen = function(x, lambda=0.1, ma=2, num=1, nv, NoisesStd=NULL,
                             normdis='1', gamma1=0.5, gamma2=0.5,
                             a=NULL, tprocs=NULL, mipgap=0, print.progress=TRUE) {
  
  n = nrow(x)  # Number of rows
  m = ncol(x)  # Number of columns
  ng = length(nv)  # Number of groups   
  

  if (is.null(tprocs)) tprocs = 1e+3
  if (is.null(NoisesStd)) {
    Noises = matrix(rnorm(ma*num*n), ncol=num)    # Noises (matriz A no artigo)
    NoisesStd = matrix(0, nrow=ma*n, ncol=num)    # Standardized Noises (matriz A* no artigo)
    for (ids in 1:num) {
      A = matrix(Noises, ncol=ma, byrow=FALSE)
      invcholA = inverseCholCov(A)
      za = as.matrix(A) %*% invcholA
      # Matriz A* no artigo pg 2 (ruido)
      NoisesStd[,ids] = as.vector(za)
    }
    
  }
  
 #Lambda adjustment
  lambdamod = lambda/(lambda*(1-ma/m) + ma/m)  
  

  
  # Inverse of cholesky factor of covariance of x
  invcholx = inverseCholCov(x)   # Caution: in R, chol(X) returns an upper triangular matrix
  # X* matrix
  zx = as.matrix(x) %*% invcholx

  
  #Starting simulations
  Stats = foreach(ids=1:num, .combine=cbind, .multicombine=TRUE, .inorder=FALSE) %dopar% {
    
    cur = Sys.time()

    if (print.progress) print(c(ids))
    #browser()

    # Standardized noise
    # za = A*
    za = matrix(NoisesStd[,ids], ncol=ma, byrow=FALSE)
    mz = m+ma
    
    if (normdis == '2') {
      z = cbind(sqrt(lambdamod)*za, sqrt(1-lambdamod)*zx) 
    } else {
      z = cbind(lambdamod*za, (1-lambdamod)*zx) 
    }
    
   
    
    # Rafael: 
    # Anv and S: auxiliary matrix and vector used for computing the distances between covariate means  
    Anv<-matrix(0,nrow=nrow(z)*ng,ncol=ncol(z)*ng)
    for(i in 1:ng){
      Anv[((i-1)*nrow(z)+1):(nrow(z)*i),((i-1)*ncol(z)+1):(ncol(z)*i)]<-z/nv[i]
    }
    Anv<-t(Anv)
    
    #Anv<-kronecker(diag(ng)/nv,z)
    
    S = rep(apply(z,2,sum)/n,ng) #Vectors of means of z, repeated ng times
    

    # Sort time limits
    tprocs = sort(tprocs)
    qtt = length(tprocs)
    
    
    if(lambda==0){z=x}
    # Starting point
    startingp = rerandomize.SSL.Gr(x=z, num=1, nv=nv, normdis=normdis, gamma1=gamma1, gamma2=gamma2, pa=0.001, print.progress=FALSE)
    wini = startingp$W[[1]] 

    
    # MatrAloc is an auxiliary matrix to hold the allocation vectors, processing times and distances. 
    # Each column corresponds to a time limit (secs) and the rows are organized as follows:
    #   1..n : binary allocations (0=control group, 1=treatment group)
    #   n+1 : total processing time
    #   n+2 : minimal distance (according to the norm specified by normdis string)
    #   n+3 : norm L1 distance
    #   n+4 : norm L2 distance
    #   n+5 : norm Linf distance
    #   n+6 : hybrid norm distance
    MatrAloc = matrix(0, nrow=(n*ng)+7, ncol=qtt)
    
    idt = 1
    trial = 0
    while (idt<=qtt) {
      tprocatu = tprocs[idt]

      dmeans = Anv %*% wini - S
      dini = calc.dist(dmeans, normdis, gamma1, gamma2)
      threshold = ifelse(is.null(a), mipgap*dini, (1-lambdamod)*a)
      
      model = list()
      if (normdis=='1') {  
        
        
        mk1<-matrix(0,n*ng,nrow=ng)
        for(i in 1:ng){
          mk1[i,(n*(i-1)+1):(n*i)]<-1
        }
        ############## SOS COnstr Matrix
        SOSM<-matrix(0,nrow=n,ncol=n*ng)
        for(i in 1:n){
          for(j in 1:ng){
            SOSM[i,(i+n*(j-1))]<-1
          }}
        
        model$obj   = c(rep(0, n*ng), rep(1,mz*ng))
        model$A = matrix(0, nrow=n+ng+(2*mz*ng), ncol=n*ng+mz*ng)
        model$A[1:n,1:(n*ng)]= SOSM
        model$A[(n+1):(n+ng),1:(n*ng)] = mk1  # 1w = nt
        model$A[(n+ng+1):(n+ng+mz*ng), 1:(n*ng)] = Anv
        diag(model$A[(n+ng+1):(n+ng+mz*ng), (n*ng)+(1:(mz*ng))]) = -1
        model$A[(n+ng+mz*ng)+(1:(mz*ng)), 1:(n*ng)] = -Anv
        diag(model$A[(n+ng+mz*ng)+(1:(mz*ng)), (n*ng)+(1:(mz*ng))]) = -1
        model$rhs   = c(rep(1,n),nv, S, -S)
        model$sense = c(rep('=',n), rep('=',ng), rep('<=', 2*mz*ng))
        model$vtype = c(rep('B', n*ng), rep('C', mz*ng))
        model$start = c(wini, abs(dmeans)) # Starting point 
        
      } else if (normdis=='2') {
        

        ######## mk1 e SOSM
        mk1<-matrix(0,n*ng,nrow=ng)
        for(i in 1:ng){
          mk1[i,(n*(i-1)+1):(n*i)]<-1
        }
        ############## SOS COnstr Matrix
        SOSM<-matrix(0,nrow=n,ncol=n*ng)
        for(i in 1:n){
          for(j in 1:ng){
            SOSM[i,(i+n*(j-1))]<-1
          }}
        
        MtrestQS<-rep(0,n*ng)
        for(i in 1:(ng-1)){MtrestQS[(i*n+1):(i*n+i)]<-1}
        
        # Matrix for quadratic component of objective function 
        model<-list()
        model$Q = matrix(0, nrow=n*ng+(mz*ng), ncol=n*ng+(mz*ng))
        diag(model$Q[n*ng+(1:(mz*ng)),n*ng+(1:(mz*ng))])=1
        
        model$obj   = rep(0, n*ng+mz*ng)
        
        model$A = matrix(0, nrow=n+ng+mz*ng+mz*ng+1, ncol=n*ng+mz*ng)
        
        model$A[1:n,1:(n*ng)]= SOSM
        model$A[(n+1):(n+ng),1:(n*ng)] = mk1  # 1w = nt
        
        
        model$A[(n+ng+1):(n+ng+mz*ng), 1:(n*ng)] = Anv
        diag(model$A[(n+ng+1):(n+ng+mz*ng), (n*ng+1):(n*ng+mz*ng)]) = -1
        
        model$A[(n+ng+mz*ng+1):(n+ng+2*mz*ng), 1:(n*ng)] = -Anv
        diag(model$A[(n+ng+mz*ng+1):(n+ng+2*mz*ng), (n*ng+1):(n*ng+mz*ng)]) = -1
        
        #Symmetry breaking constraints
        model$A[n+ng+2*mz*ng+1, 1:(n*ng)]<-MtrestQS
        
        
        model$start = c(wini, dmeans) # Starting point
        model$rhs   = c(rep(1,n),nv, S,-S,0)
        model$sense = c(rep('=',n), rep('=',ng), rep('<=', 2*mz*ng),'<=')
        model$vtype = c(rep('B', n*ng), rep('C', mz*ng))
        model$modelsense <- 'min'
        
        
        

      } else if (normdis=='I') {
        
        #########SOSM Mk1 and mun 
        ############## SOS COnstr Matrix
        SOSM<-matrix(0,nrow=n,ncol=n*ng)
        for(i in 1:n){
          for(j in 1:ng){
            SOSM[i,(i+n*(j-1))]<-1
          }}
        
        ########
        mk1<-matrix(0,n*ng,nrow=ng)
        for(i in 1:ng){
          mk1[i,(n*(i-1)+1):(n*i)]<-1
        }
        
        ######################### matrix
        mun<-matrix(rep(c(rep(1,mz),rep(0,(mz*ng))),ng),nrow=(mz*ng))[,1:ng]
        
        model$obj   = c(rep(0, n*ng), rep(1,ng))
        model$A = matrix(0, nrow=n+ng+(2*mz*ng), ncol=n*ng+ng)
        model$A[1:n,1:(n*ng)]= SOSM
        model$A[(n+1):(n+ng),1:(n*ng)] = mk1  # 1w = nt
        model$A[(n+ng+1):(n+ng+mz*ng), 1:(n*ng)] = Anv
        model$A[(n+ng+1):(n+ng+mz*ng), (n*ng+1):(n*ng+ng)] = -mun
        model$A[(n+ng+mz*ng)+(1:(mz*ng)), 1:(n*ng)] = -Anv
        model$A[(n+ng+mz*ng)+(1:(mz*ng)), (n*ng+1):(n*ng+ng)] = -mun
        model$rhs   = c(rep(1,n),nv, S, -S)
        model$sense = c(rep('=',n), rep('=',ng), rep('<=', 2*mz*ng))
        model$vtype = c(rep('B', n*ng), rep('C', ng))
        model$start = c(wini, rep(max(abs(dmeans)),ng)) # Starting point #Depois mudar wini*k para um wini generalizado
        
        
      } else {
        
        ############## SOS COnstr Matrix
        SOSM<-matrix(0,nrow=n,ncol=n*ng)
        for(i in 1:n){
          for(j in 1:ng){
            SOSM[i,(i+n*(j-1))]<-1
          }}
        
        ########matriz de 1ns
        mk1<-matrix(0,n*ng,nrow=ng)
        for(i in 1:ng){
          mk1[i,(n*(i-1)+1):(n*i)]<-1
        }
        
        MtrestQS<-rep(0,n*ng)
        for(i in 1:(ng-1)){MtrestQS[(i*n+1):(i*n+i)]<-1}
        
        
        # min [ 0 ... 0 ] [gamma1 ... gamma1] [gamma2*sqrt(m)] * t([ w1 ... wn ] [ d1 ... dm] [ u ]) 
        model$obj   = c(rep(0, n*ng), rep(gamma1,mz*ng), rep(gamma2*sqrt(m),ng))
        #  [ 1 ..10..... 0 ] [0 0 ...   0] [0...0]    | w1 |  =  | n1 |
        #  [ 0... 1...1...0] [0 0 ...   0] [0...0]    | w1 |  =  | n2 |
        #  [ 0 0 0...01...1] [0 0 ...   0] [0...0]    | w1 |  =  | ng |
        #  [      Q        ] [ -I(mz*k)  ] [0...0]    | w2 |  <= |  S |
        #  [     -Q        ] [ -I(mz*k)  ] [0...0]  * | .. |  <= | -S |
        #  [      0        ] [           ] [1...0]    | wn |  >= |  0 |
        #  [      0        ] [ -I(mz*k)  ] [0.1.0]    | d1 |
        #  [      0        ] [           ] [0...1]    | .. |
        #                                             | dm |
        #                                             | u  |
       
        
        model$A = matrix(0, nrow=n+ng+3*mz*ng+1, ncol=n*ng+mz*ng+ng)
        # sum W.j=1, 1w = nt
        model$A[1:n,1:(n*ng)]= SOSM
        model$A[(n+1):(n+ng),1:(n*ng)] = mk1  # 1w = nt
        # Qw - d <= S
        model$A[(n+ng+1):(n+ng+mz*ng), 1:(n*ng)] = Anv
        diag(model$A[(n+ng+1):(n+ng+mz*ng), (n*ng)+(1:(mz*ng))]) = -1
        # -Qw - d <= -S 
        model$A[(n+ng+mz*ng)+(1:(mz*ng)), 1:(n*ng)] = -Anv #-Q
        diag(model$A[(n+ng+mz*ng)+(1:(mz*ng)), (n*ng)+(1:(mz*ng))]) = -1
        # -Id + u >= 0
        diag(model$A[(n+ng+2*(mz*ng))+(1:(mz*ng)), (n*ng)+(1:(mz*ng))]) = -1
        model$A[(n+ng+2*(mz*ng))+(1:(mz*ng)), (n*ng)+(mz*ng)+(1:ng)] = matrix(rep(c(rep(1,mz),rep(0,(mz*ng))),ng),nrow=(mz*ng))[,1:ng]
        #Symmetry breaking constraints
        model$A[(n+ng+2*(mz*ng))+((mz*ng))+1, 1:(n*ng)]<-MtrestQS
        
        model$rhs   = c(rep(1,n),nv, S, -S, rep(0,mz*ng),0)
        model$sense = c(rep('=',n), rep('=',ng), rep('<=', 2*mz*ng), rep('>=', mz*ng),'<=')
        model$vtype = c(rep('B', n*ng), rep('C', mz*ng), rep('C',ng))
        model$start = c(wini, abs(dmeans), rep(max(abs(dmeans)),ng)) # Starting point
        
      }
      
      rtime = as.double(difftime(Sys.time(),cur,units='secs'))
      TimeLimit = max(c(1, tprocatu-rtime))
      
      params = list(MIPGapAbs=threshold, OutputFlag=0, TimeLimit=TimeLimit, Threads=1)
      resgur = gurobi(model, params)
      objval = resgur$objval
      
      rtime = as.numeric(difftime(Sys.time(),cur,units='secs'))
      
      W.best = resgur$x[1:(n*ng)]
      dmeans = Anv %*% W.best - S
      bestD = calc.dist(dmeans, normdis, gamma1, gamma2)
      gap = resgur$mipgap
      timeout = ifelse(resgur$status == "OPTIMAL", 0, 1)
      
      MatrAloc[,idt] = c(W.best, rtime, bestD, 
                         calc.dist(dmeans, normdis='1', gamma1, gamma2), calc.dist(dmeans, normdis='2', gamma1, gamma2),
                         calc.dist(dmeans, normdis='I', gamma1, gamma2), calc.dist(dmeans, normdis='1I', gamma1, gamma2),gap)
      
      if (print.progress) print(c(ids, idt, rtime, bestD, objval))
      
      #browser()

      wini = W.best 

      idt = idt+1
    } # while (idt<=qtt)
    
    MatrAloc

  }  # foreach
  
  qtt = length(tprocs)

  if (num*qtt==1) Stats = matrix(Stats, ncol=1)
  
  W = list()
  times = list()
  dists = list()
  distsL1 = list()
  distsL2 = list()
  distsLI = list()
  distsL1I = list()
  MipGap = list()
  for (idt in 1:qtt) {
    cols = (0:(num-1))*qtt+idt
    W[[idt]] = Stats[1:(n*ng),cols]
    times[[idt]] = Stats[(n*ng)+1,cols]
    dists[[idt]] = Stats[(n*ng)+2,cols]
    distsL1[[idt]] = Stats[(n*ng)+3,cols]
    distsL2[[idt]] = Stats[(n*ng)+4,cols]
    distsLI[[idt]] = Stats[(n*ng)+5,cols]
    distsL1I[[idt]] = Stats[(n*ng)+6,cols]
    MipGap[[idt]] = Stats[(n*ng)+7,cols]
}
  
  return(list(Stats=Stats, W=W, times=times, dists=dists, distsL1=distsL1, distsL2=distsL2, 
              distsLI=distsLI, distsL1I=distsL1I,MipGap=MipGap))

}


