#require(robCompositions)
require(psych)

source('MultiCore.R')

####### generates a random allocation matrix for a vector nv=(n1,n2,n3...n)
GenW<- function(nv){
  n<-sum(nv)
  W<-matrix(rep(0,n*length(nv)), ncol=length(nv)) 
  Vac<-c()
  valoc<-seq(1:n)
  for(i in 1:length(nv)){
    valoc<-valoc[!(valoc %in% Vac)]
    VW<-sample(valoc,nv[i],replace = F)
    Vac<-c(Vac,VW)
    W[VW,i]=1}
  return(W)}
#############################


# compute covariance of x and its inverse
inverseCov = function(x) {
  CovX = cov(x)
  cholCovX = chol(CovX)
  invchol = solve(cholCovX, diag(ncol(x)), tol=.Machine$double.eps*1e-5)
  ICovX = invchol %*% t(invchol) 
  return(ICovX)  
}


# compute the inverse of Cholesky factor of the covariance matrix of x
inverseCholCov = function(x) {
  CovX = cov(x)
  cholCovX = chol(CovX)
  invchol = solve(cholCovX, diag(ncol(x)), tol=.Machine$double.eps*1e-5)
  return(invchol)  
}


# convert the matrix of covariates to a standardized form
Std_Covariates = function (X, nt, nc) {

  # Inverse of cholesky factor of covariance of x
  invcholx = inverseCholCov(X)   # Caution: in R, chol(X) returns an upper triangular matrix
  Zx = as.matrix(X) %*% invcholx

  Rx = (nc+nt)/(nc*nt)*t(Zx)
  Sx = apply(Zx,2,sum)/nc
  
  return(list(Zx = Zx, Rx=Rx, Sx=Sx))
}

#
#  Distance computation under norms 1, 2, inf and 1-Inf
#
#  dmeans: vector of mean differences between groups
#  normdis: '1' = norm L1, '2' = norm L2, 'I' = norm Linf, 'I1' = hybrid norm 
calc.dist = function(dmeans, normdis, gamma1, gamma2) {
  return(
    ifelse(normdis=='1', sum(abs(dmeans)),                # norm 1
    ifelse(normdis=='2', sqrt(t(dmeans) %*% dmeans),     # norm 2
    #ifelse(normdis=='2', t(dmeans) %*% dmeans,            # norm 2
    ifelse(normdis=='I', max(abs(dmeans)),                # norm inf
    gamma1*sum(abs(dmeans)) + gamma2*sqrt(length(dmeans))*max(abs(dmeans))))) # 1-infinity norm
  )
} 



#
# Given a matrix of covariates X and a matrix of allocations W,  
# compute the standardized Mahalanobis distance for each allocation.
#
calc.M.std = function(X, W) {
  n = nrow(X)
  n1 = sum(W[,1])
  n0 = n-n1
  
  StdCov = Std_Covariates(X, n1, n0)
  
  MahaDist = rep(0, ncol(W))
  for(jj in 1:ncol(W))
  {
    dmeans = StdCov$Rx %*% W[,jj] - StdCov$Sx
    MahaDist[jj] = calc.dist(dmeans, normdis='2')
  }
  
  return(MahaDist)
}

#compute generalizaed sums of means
calc.M.std.Gen = function(X, W, nv){
    n = sum(nv)
    ng = length(nv)
    invcholx = inverseCholCov(X)   # Caution: in R, chol(X) returns an upper triangular matrix
    Zx = as.matrix(X) %*% invcholx
  
    S = rep(apply(Zx,2,sum)/n,ng)
    
    Qx = t(kronecker(diag(ng)/nv,Zx))
    
    MahaDist = rep(0, ncol(W))
    for(jj in 1:ncol(W)){
      dmeans = Qx %*% W[,jj] - S
      MahaDist[jj] = calc.dist(dmeans, normdis='2')
    }
    return(MahaDist)
}

# computes squared sums of Mahalanobis distances over each group and global mean
calc.Mahalanobis.std.Gen = function(X, W, nv){
  n = sum(nv)
  ng = length(nv)
  invcholx = inverseCholCov(X)   # Caution: in R, chol(X) returns an upper triangular matrix
  Zx = as.matrix(X) %*% invcholx
  
  S = rep(apply(Zx,2,sum)/n,ng)
  
  Qx = t(kronecker(diag(ng)/nv,Zx))
  
  MahaDist = rep(0, ncol(W))
  for(jj in 1:ncol(W)){
    dmeans = Qx %*% W[,jj] - S
    MahaDist[jj] = calc.dist(dmeans, normdis='2')
  }
  return(MahaDist)
}


# computes sums of Mahalanobis distances between each group and global means
calc.M.std.Grupos = function(X, W, nv){
  n = sum(nv)
  ng = length(nv)
  W<-as.data.frame(W)
  ng<-length(nv)
  idxc<-c(0,c(1:ng)*nrow(X)) 
  idxr<-c(0,c(1:ng)*ncol(X))
  
  invcholx = inverseCholCov(X)   # Caution: in R, chol(X) returns an upper triangular matrix
  
  Zx = as.matrix(X) %*% invcholx
  
  S = rep(apply(Zx,2,sum)/n,ng)
  
  Qx = t(kronecker(diag(ng)/nv,Zx))
  
  MahaDist = rep(0, ncol(W))
  for(jj in 1:ncol(W)){
    Mahdist_Grupo<-c()
    for(i in 1:ng){
      dmeans<-Qx[(idxr[i]+1):idxr[i+1],(idxc[i]+1):idxc[i+1]] %*% W[(idxc[i]+1):idxc[i+1],jj]-S[(idxr[i]+1):idxr[i+1]]
      Mahdist_Grupo[i]<-calc.dist(dmeans, normdis='2')
    }
    MahaDist[jj] = sum(Mahdist_Grupo)
  }
  return(MahaDist)
}



calc.diff.means = function(v,w) mean(v[w==1],na.rm=TRUE) - mean(v[w==0], na.rm=TRUE)

#difference between group mean and global mean for each covariate
calc.diff.means.center = function(v,w) mean(v[w==1],na.rm=TRUE) - mean(v, na.rm=TRUE) 

#maximum pairwise difference between groups for each covariate
calc.diff.means.combn.max = function(v,M){
  cbn<-combn(ncol(M),2)
  difs<-c()
  for(ii in 1:dim(cbn)[2]){
    difs[ii]<-abs(mean(v[M[,cbn[1,ii]]==1],na.rm=TRUE)-mean(v[M[,cbn[2,ii]]==1],na.rm=TRUE))
  }
  return(max(difs))
}


#matrix os differences between each group and global mean
calc.diff.means.gen = function(v,W,ng){
  v<-as.data.frame(v)
  M<-matrix(W, ncol=ng)
  difs<-matrix(0,nrow=ng,ncol=ncol(v))
  for(i in 1:ng){
    difs[i,]<-colMeans(v[M[,i]==1,])-colMeans(v)
  }
  return(difs)
}


######### boxplos for balance results
Boxplot_Methods<-function(diffs, covnames, Alocmethods=c("1.Haphazard","2.Rerandomization","3.Pure Random"), Leg.labels=NULL, titleg=NULL){
  dadosL<-data.frame(diffs[[1]])
  dadosL$Method<-Alocmethods[1]
  L<-length(diffs)
  for(i in 2:L){
    Mtr<-data.frame(diffs[[i]])
    Mtr$Method<-Alocmethods[i]
    dadosL<-rbind(dadosL,Mtr)
  }
  
  names(dadosL)[1:(dim(dadosL)[2]-1)]<-covnames
  
  if(is.null(Leg.labels)){Leg.labels<-Alocmethods}
  
  if(is.null(titleg)){titleg<-c(" ")}
  
  p<-ggplot(data = melt(dadosL), aes(y=value, x= variable, fill = rev(Method), col=rev(Method))) +
    stat_boxplot(geom ='errorbar')+
    geom_boxplot(outlier.colour = NULL) +
    coord_flip() +
    #scale_fill_brewer(palette = "Pastel1", direction=-1, labels=rev(Leg.labels)) +
    #scale_color_brewer(palette="Set1",direction=-1,labels=rev(Leg.labels))+
    scale_fill_brewer(palette = "Pastel1", direction=-1, labels=rev(c(expression(lambda~"*"==0.01),"Rerandomization","Pure Random"))) +
    scale_color_brewer(palette="Set1", direction=-1,labels=rev(c(expression(lambda~"*"==0.01),"Rerandomization","Pure Random")))+
    guides(fill = guide_legend(reverse = T, nrow=1, byrow=T), color=guide_legend(reverse = T, nrow=1,byrow=T))+
    labs(title = titleg, x = " ", y = " ")+
    theme_bw()+
    theme(legend.position = "top",
          legend.background = element_rect(fill="transparent"),
          legend.spacing.x = unit(0.3, 'cm'),
          legend.box.spacing = unit(.01, "cm"), # adjusts distance of box from x-axis
          legend.title = element_blank(),
          legend.box.just = "bottom",
          legend.margin = margin(c(5, 5, 5, 0)),
          legend.text = element_text(size = 15,margin = margin(r = 30, unit = "pt")),
          #legend.text=element_text(size = 15),
          axis.text.x = element_text(size = 15),
          axis.text.y = element_text(size = 15),
          axis.line.x = element_line(),
          axis.ticks.length = unit(0.3, "cm"),
          panel.border = element_blank())
  
  
  return(p)
}

