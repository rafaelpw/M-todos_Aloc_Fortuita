#
#   Simulations for Haphazard method and Rerandomization for fixed times
#


rm(list=ls())

library(dplyr)
source('hhFunctions_gurobi_Gr.R')
source('pure_random_Gr.R')
source('genFunctions.R')

dados<-read.table("POP_SERRANA_COVID.txt", dec=",", header = T, sep = "|", fileEncoding = "latin1")

dados<-dados[,c(26,27,30,33,34,35,39,46,54,56,58,59,65,67,98)]


x<-dados

n = nrow(x)
#List of groups
Listgr<-list()
Listgr[[1]]<-c(12,11,11,11)



# Number of simulations 
nsim = 300
normdis =  c('1I')  #'1', '2', 'I', '1I'
#normdisrr = '2'
tprocsvec = c(30)
qttprocs=length(tprocsvec)


lambdas=c(0.01,1,2)
qtlambdas = length(lambdas)


mnoise = 2   # number of columns of noise matrix

gamma1 = gamma2 = 1 

for(nd in 1:length(normdis)){
  for(t in 1:qttprocs){
    tprocs=tprocsvec[t]
    for(idg in 1:1){
      nv<-Listgr[[idg]]
      ng <- length(nv)
      
      nvstr<-paste(nv,collapse=" ")
      
      diretsai = paste0('output-',normdis[nd],'-',nvstr,'-',tprocs,'-Serrana')
      if (!file.exists(diretsai)) {
        dir.create(diretsai)
      }
      
      ##########################
      
      
      MatrNoises = matrix(rnorm(mnoise*nsim*nrow(x)), ncol=nsim)  # Noises 
 
      
      # All Noise Matrices
      MatrNoiseStd = matrix(0,nrow=mnoise*nrow(x), ncol=nsim)    # Standardized Noises
      for (ids in 1:nsim) {
        A = matrix(MatrNoises[,ids], ncol=mnoise, byrow=FALSE)
        invcholA = inverseCholCov(A)
        za = as.matrix(A) %*% invcholA
        MatrNoiseStd[,ids] = as.vector(za)
      }
      
      
        
      #idc=1
      for (idc in 1:qtlambdas) {
      
        lambda = lambdas[idc]
        
        print(c(idc, lambda))
      
        if (lambda<1) {
          # Haphazard
          Aloc = hapsamplingGurobi_Gen(x=x, lambda=lambda, ma=mnoise, num=nsim, nv=nv, NoisesStd=MatrNoiseStd,
                                   normdis=normdis[nd], gamma1=gamma1, gamma2=gamma2, tprocs=tprocs)
        } else if (lambda==1) {
          # Rerandomization
          # if the current criterion is the 1-infinity norm, rerandomize optimizing the norm L2 
          normdisrr = ifelse(normdis=='1I', '2', normdis)  
          Aloc = rerandomize.SSL.Gr(x, num=nsim, nv=nv, normdis=normdisrr, gamma1=gamma1, gamma2=gamma2, tprocs=tprocs)
        } else {
          Aloc = pureRandom.Gr(x, num=nsim, nv=nv) 
        }
      
        #attach(Aloc)
        # 
      
        nmarqaloca = paste(diretsai, '/T_', normdis[nd], '_', lambda, '.txt', sep='')
        write.table(Aloc$Stats, file=nmarqaloca, sep='\t', col.names=FALSE, row.names=FALSE)
      
        
        #browser()
      }
    
  }
  
  }
}

