###################Rotina para aleatoriza��o pura

pureRandom = function(x, num=1, nv) {
  
  n = nrow(x)  # numero de linhas
  m = ncol(x)  # numero de colunas  
  ng = length(nv)  # numero de grupos  
  

  W.temp = as.vector(GenW(nv)) #Fun��o que gera a matriz de aloca��o aleat�ria 
  
  # nao h� controle do tempo
  rtime = 1

  

  invcholx = inverseCholCov(x)   
  # Matriz A* no artigo (dados)
  z = as.matrix(x) %*% invcholx
  
  # ver documenta��o
  Anv<-matrix(0,nrow=nrow(z)*ng,ncol=ncol(z)*ng)
  for(i in 1:ng){
    Anv[((i-1)*nrow(z)+1):(nrow(z)*i),((i-1)*ncol(z)+1):(ncol(z)*i)]<-z/nv[i]
  }
  Anv<-t(Anv)
  
  S = rep(apply(z,2,sum)/n,ng) 
  
  
  #
  # La�o principal 
  # (todas as alocacoes/simulacoes em multicore)
  #
  Stats = foreach(ids=1:num, .combine=cbind, .multicombine=TRUE, .inorder=FALSE) %dopar% {
    W.best = as.vector(GenW(nv))
    dmeans = Anv %*% W.temp - S
    bestD = calc.dist(dmeans, normdis, gamma1, gamma2)
    
    # MatrAloc � uma matriz auxiliar. 
    # As colunas s�o organizadas como segue:
    #   1..n : vetor de aloca��es
    #   n+1 : tempo de processamento
    #   n+2 : dist�ncia m�nima
    #   n+3 : quantidade de ensaios
    #   n+4 : dist�ncia na norma L1 
    #   n+5 : dist�ncia na norma L2 
    #   n+6 : dist�ncia na norma Linf 
    #   n+7 : dist�ncia na norma h�brida
    MatrAloc = matrix(
      c(W.best, rtime, bestD, 
        calc.dist(dmeans, normdis='1', gamma1, gamma2), calc.dist(dmeans, normdis='2', gamma1, gamma2),
        calc.dist(dmeans, normdis='I', gamma1, gamma2), calc.dist(dmeans, normdis='1I', gamma1, gamma2)),
      ncol=1)
    
    MatrAloc
  }  # foreach


  if (num==1) Stats = matrix(Stats, ncol=1)
  
  W = list()
  times = list()
  dists = list()
  distsL1 = list()
  distsL2 = list()
  distsLI = list()
  distsL1I = list()

  #browser()
  
  W[[1]] = Stats[1:(n*ng),]
  times[[1]] = Stats[(n*ng)+1,]
  dists[[1]] = Stats[(n*ng)+2,]
  distsL1[[1]] = Stats[(n*ng)+3,]
  distsL2[[1]] = Stats[(n*ng)+4,]
  distsLI[[1]] = Stats[(n*ng)+5,]
  distsL1I[[1]] = Stats[(n*ng)+6,]

  return(list(Stats=Stats, W=W, times=times, dists=dists, distsL1=distsL1, distsL2=distsL2, 
              distsLI=distsLI, distsL1I=distsL1I))
}


