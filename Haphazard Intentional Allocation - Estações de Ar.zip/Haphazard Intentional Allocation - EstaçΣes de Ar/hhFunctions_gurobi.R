###################
#
# Haphazard sampling
#
#


require(gurobi)

source('MultiCore.r')
source('rrFunctions.r')


#
#  Otimizacao norma L1, L2 ou Linf
#
# lambda: Ru�do (0 < lambda < 1)
# ma: numero de colunas da matriz de ruido
# num: n�mero de aloca��es
# mipgap: Diferen�a relativa entre a dist�ncia atual e limite inferior
# normdis: norma de dist�ncia: '1' (Manhattan), '2' (Mahalanobis), 'I' (infinito, Max),
# '1I' (1-Inf norma: H�brida)
# gamma1, gamma2: par�metro em [0,1] para a norma H�brida:
# norma '1I' = gamma1 * norm1 + gamma2 * sqrt(m) * norminf
# a: limite de dist�ncia
#
hapsamplingGurobi_Gen = function(x, lambda=0.1, ma=2, num=1, nv, NoisesStd=NULL,
                             normdis='1', gamma1=0.5, gamma2=0.5,
                             a=NULL, tprocs=NULL, mipgap=0, print.progress=TRUE) {
  
  n = nrow(x)  # numero de linhas
  m = ncol(x)  # numero de colunas  
  ng = length(nv)  # n�mero de grupos   
  

  if (is.null(tprocs)) tprocs = 1e+3
  if (is.null(NoisesStd)) {
    Noises = matrix(rnorm(ma*num*n), ncol=num)    # Matriz de Ru�dos
    NoisesStd = matrix(0, nrow=ma*n, ncol=num)    
    for (ids in 1:num) {
      A = matrix(Noises, ncol=ma, byrow=FALSE)
      invcholA = inverseCholCov(A)
      za = as.matrix(A) %*% invcholA
      # Matriz A* no artigo pg 2 (ruido)
      NoisesStd[,ids] = as.vector(za)
    }
    
  }
  
  #ajuste para tornar lambda interpret?vel
  #sem trocar a fc objetivo.
  # lambdamod --> lambda 
  # lambda --> lambda*
  lambdamod = lambda/(lambda*(1-ma/m) + ma/m)  #ma = numero de colunas da matriz de ruidos
  
  

  # Matriz L 
  invcholx = inverseCholCov(x)   # Caution: in R, chol(X) returns an upper triangular matrix
  # Matriz A* 
  zx = as.matrix(x) %*% invcholx

  #
  # Laco principal 
  # (todas as alocacoes/simulacoes em multicore)
  #
  Stats = foreach(ids=1:num, .combine=cbind, .multicombine=TRUE, .inorder=FALSE) %dopar% {
    
    cur = Sys.time()

    if (print.progress) print(c(ids))
    #browser()

    #ru�dos
    # za = "Z*" (ou A* aplicado sobre o Z)
    za = matrix(NoisesStd[,ids], ncol=ma, byrow=FALSE)
    mz = m+ma
    
    if (normdis == '2') {
      z = cbind(sqrt(lambdamod)*za, sqrt(1-lambdamod)*zx) 
    } else {
      z = cbind(lambdamod*za, (1-lambdamod)*zx) 
    }
    
   
    
    # ver documentacao
    # Anv and S: Matrizes auxiliares para implementa��o dos modelos   
    Anv<-matrix(0,nrow=nrow(z)*ng,ncol=ncol(z)*ng)
    for(i in 1:ng){
      Anv[((i-1)*nrow(z)+1):(nrow(z)*i),((i-1)*ncol(z)+1):(ncol(z)*i)]<-z/nv[i]
    }
    Anv<-t(Anv)
    
    #Anv<-kronecker(diag(ng)/nv,z) #Outra op��o para gerar a matriz auxiliar
    
    S = rep(apply(z,2,sum)/n,ng) #Valores ideais
    

    # Sort time limits
    tprocs = sort(tprocs)
    qtt = length(tprocs)
    
    
    if(lambda==0){z=x}
    # Starting point
    startingp = rerandomize.SSL(x=z, num=1, nv=nv, normdis=normdis, gamma1=gamma1, gamma2=gamma2, pa=0.001, print.progress=FALSE)
    wini = startingp$W[[1]] 

    
    
    # MatrAloc � uma matriz auxiliar. 
    # As colunas s�o organizadas como segue:
    #   1..n : vetor de aloca��es
    #   n+1 : tempo de processamento
    #   n+1 : dist�ncia m�nima
    #   n+2 : quantidade de ensaios
    #   n+3 : dist�ncia na norma L1 
    #   n+4 : dist�ncia na norma L2 
    #   n+5 : dist�ncia na norma Linf 
    #   n+6 : dist�ncia na norma h�brida
    #   n+7 : Gap
    MatrAloc = matrix(0, nrow=(n*ng)+7, ncol=qtt)
    
    idt = 1
    trial = 0
    while (idt<=qtt) {
      tprocatu = tprocs[idt]

      dmeans = Anv %*% wini - S
      dini = calc.dist(dmeans, normdis, gamma1, gamma2)
      threshold = ifelse(is.null(a), mipgap*dini, (1-lambdamod)*a)
      
      model = list()
      if (normdis=='1') {  
        
        
        ######## mk1 e SOSM s�o matrizes auxiliares para o modelo
        mk1<-matrix(0,n*ng,nrow=ng)
        for(i in 1:ng){
          mk1[i,(n*(i-1)+1):(n*i)]<-1
        }
        
        SOSM<-matrix(0,nrow=n,ncol=n*ng)
        for(i in 1:n){
          for(j in 1:ng){
            SOSM[i,(i+n*(j-1))]<-1
          }}
        
        model$obj   = c(rep(0, n*ng), rep(1,mz*ng))
        model$A = matrix(0, nrow=n+ng+(2*mz*ng), ncol=n*ng+mz*ng)
        model$A[1:n,1:(n*ng)]= SOSM
        model$A[(n+1):(n+ng),1:(n*ng)] = mk1  # 1w = nt
        model$A[(n+ng+1):(n+ng+mz*ng), 1:(n*ng)] = Anv
        diag(model$A[(n+ng+1):(n+ng+mz*ng), (n*ng)+(1:(mz*ng))]) = -1
        model$A[(n+ng+mz*ng)+(1:(mz*ng)), 1:(n*ng)] = -Anv
        diag(model$A[(n+ng+mz*ng)+(1:(mz*ng)), (n*ng)+(1:(mz*ng))]) = -1
        model$rhs   = c(rep(1,n),nv, S, -S)
        model$sense = c(rep('=',n), rep('=',ng), rep('<=', 2*mz*ng))
        model$vtype = c(rep('B', n*ng), rep('C', mz*ng))
        model$start = c(wini, abs(dmeans)) # Ponto inicial 
        
      } else if (normdis=='2') {
        

        ######## mk1 e SOSM s�o matrizes auxiliares para o modelo
        mk1<-matrix(0,n*ng,nrow=ng)
        for(i in 1:ng){
          mk1[i,(n*(i-1)+1):(n*i)]<-1
        }
        
        SOSM<-matrix(0,nrow=n,ncol=n*ng)
        for(i in 1:n){
          for(j in 1:ng){
            SOSM[i,(i+n*(j-1))]<-1
          }}
        
        
        #restri��o quebra de simetria Xip = 0 para todo i<p
        MtrestQS<-rep(0,n*ng)
        for(i in 1:(ng-1)){MtrestQS[(i*n+1):(i*n+i)]<-1}
        
        # Matriz para a componente quadr�tica
        model<-list()
        model$Q = matrix(0, nrow=n*ng+(mz*ng), ncol=n*ng+(mz*ng))
        diag(model$Q[n*ng+(1:(mz*ng)),n*ng+(1:(mz*ng))])=1
        
        model$obj   = rep(0, n*ng+mz*ng)
        
        model$A = matrix(0, nrow=n+ng+mz*ng+mz*ng+1, ncol=n*ng+mz*ng)
        
        model$A[1:n,1:(n*ng)]= SOSM
        model$A[(n+1):(n+ng),1:(n*ng)] = mk1  # 1w = nt
        
        
        model$A[(n+ng+1):(n+ng+mz*ng), 1:(n*ng)] = Anv
        diag(model$A[(n+ng+1):(n+ng+mz*ng), (n*ng+1):(n*ng+mz*ng)]) = -1
        
        model$A[(n+ng+mz*ng+1):(n+ng+2*mz*ng), 1:(n*ng)] = -Anv
        diag(model$A[(n+ng+mz*ng+1):(n+ng+2*mz*ng), (n*ng+1):(n*ng+mz*ng)]) = -1
        
        #Quebra de simetria
        model$A[n+ng+2*mz*ng+1, 1:(n*ng)]<-MtrestQS
        
        
        model$start = c(wini, dmeans) # Starting point
        model$rhs   = c(rep(1,n),nv, S,-S,0)
        model$sense = c(rep('=',n), rep('=',ng), rep('<=', 2*mz*ng),'<=')
        model$vtype = c(rep('B', n*ng), rep('C', mz*ng))
        model$modelsense <- 'min'
        
        
        

      } else if (normdis=='I') {
        

        SOSM<-matrix(0,nrow=n,ncol=n*ng)
        for(i in 1:n){
          for(j in 1:ng){
            SOSM[i,(i+n*(j-1))]<-1
          }}
        
        ########matriz de 1ns
        mk1<-matrix(0,n*ng,nrow=ng)
        for(i in 1:ng){
          mk1[i,(n*(i-1)+1):(n*i)]<-1
        }
        
        ######################### matriz
        mun<-matrix(rep(c(rep(1,mz),rep(0,(mz*ng))),ng),nrow=(mz*ng))[,1:ng]
        
        model$obj   = c(rep(0, n*ng), rep(1,ng))
        model$A = matrix(0, nrow=n+ng+(2*mz*ng), ncol=n*ng+ng)
        model$A[1:n,1:(n*ng)]= SOSM
        model$A[(n+1):(n+ng),1:(n*ng)] = mk1  # 1w = nt
        model$A[(n+ng+1):(n+ng+mz*ng), 1:(n*ng)] = Anv
        model$A[(n+ng+1):(n+ng+mz*ng), (n*ng+1):(n*ng+ng)] = -mun
        model$A[(n+ng+mz*ng)+(1:(mz*ng)), 1:(n*ng)] = -Anv
        model$A[(n+ng+mz*ng)+(1:(mz*ng)), (n*ng+1):(n*ng+ng)] = -mun
        model$rhs   = c(rep(1,n),nv, S, -S)
        model$sense = c(rep('=',n), rep('=',ng), rep('<=', 2*mz*ng))
        model$vtype = c(rep('B', n*ng), rep('C', ng))
        model$start = c(wini, rep(max(abs(dmeans)),ng))
        
        
      } else {
        
        
        SOSM<-matrix(0,nrow=n,ncol=n*ng)
        for(i in 1:n){
          for(j in 1:ng){
            SOSM[i,(i+n*(j-1))]<-1
          }}
        
        ########matriz de 1ns
        mk1<-matrix(0,n*ng,nrow=ng)
        for(i in 1:ng){
          mk1[i,(n*(i-1)+1):(n*i)]<-1
        }
        
        #restri��o quebra de simetria Xip = 0 para todo i<p
        MtrestQS<-rep(0,n*ng)
        for(i in 1:(ng-1)){MtrestQS[(i*n+1):(i*n+i)]<-1}
        
        
        # min [ 0 ... 0 ] [gamma1 ... gamma1] [gamma2*sqrt(m)] * t([ w1 ... wn ] [ d1 ... dm] [ u ]) 
        model$obj   = c(rep(0, n*ng), rep(gamma1,mz*ng), rep(gamma2*sqrt(m),ng))
        #  [ 1 ..10..... 0 ] [0 0 ...   0] [0...0]    | w1 |  =  | n1 |
        #  [ 0... 1...1...0] [0 0 ...   0] [0...0]    | w1 |  =  | n2 |
        #  [ 0 0 0...01...1] [0 0 ...   0] [0...0]    | w1 |  =  | ng |
        #  [      Q        ] [ -I(mz*k)  ] [0...0]    | w2 |  <= |  S |
        #  [     -Q        ] [ -I(mz*k)  ] [0...0]  * | .. |  <= | -S |
        #  [      0        ] [           ] [1...0]    | wn |  >= |  0 |
        #  [      0        ] [ -I(mz*k)  ] [0.1.0]    | d1 |
        #  [      0        ] [           ] [0...1]    | .. |
        #                                             | dm |
        #                                             | u  |
       
        
        model$A = matrix(0, nrow=n+ng+3*mz*ng+1, ncol=n*ng+mz*ng+ng)
        # sum W.j=1, 1w = nt
        model$A[1:n,1:(n*ng)]= SOSM
        model$A[(n+1):(n+ng),1:(n*ng)] = mk1  # 1w = nt
        # Qw - d <= S
        model$A[(n+ng+1):(n+ng+mz*ng), 1:(n*ng)] = Anv
        diag(model$A[(n+ng+1):(n+ng+mz*ng), (n*ng)+(1:(mz*ng))]) = -1
        # -Qw - d <= -S 
        model$A[(n+ng+mz*ng)+(1:(mz*ng)), 1:(n*ng)] = -Anv #-Q
        diag(model$A[(n+ng+mz*ng)+(1:(mz*ng)), (n*ng)+(1:(mz*ng))]) = -1
        # -Id + u >= 0
        diag(model$A[(n+ng+2*(mz*ng))+(1:(mz*ng)), (n*ng)+(1:(mz*ng))]) = -1
        model$A[(n+ng+2*(mz*ng))+(1:(mz*ng)), (n*ng)+(mz*ng)+(1:ng)] = matrix(rep(c(rep(1,mz),rep(0,(mz*ng))),ng),nrow=(mz*ng))[,1:ng]
        #Quebra de simetria
        model$A[(n+ng+2*(mz*ng))+((mz*ng))+1, 1:(n*ng)]<-MtrestQS
        
        model$rhs   = c(rep(1,n),nv, S, -S, rep(0,mz*ng),0)
        model$sense = c(rep('=',n), rep('=',ng), rep('<=', 2*mz*ng), rep('>=', mz*ng),'<=')
        model$vtype = c(rep('B', n*ng), rep('C', mz*ng), rep('C',ng))
        model$start = c(wini, abs(dmeans), rep(max(abs(dmeans)),ng)) # Starting point
        
      }
      
      rtime = as.double(difftime(Sys.time(),cur,units='secs'))
      TimeLimit = max(c(1, tprocatu-rtime))
      
      params = list(MIPGapAbs=threshold, OutputFlag=0, TimeLimit=TimeLimit, Threads=1)
      resgur = gurobi(model, params)
      objval = resgur$objval
      
      rtime = as.numeric(difftime(Sys.time(),cur,units='secs'))
      
      W.best = resgur$x[1:(n*ng)]
      dmeans = Anv %*% W.best - S
      bestD = calc.dist(dmeans, normdis, gamma1, gamma2)
      gap = resgur$mipgap
      timeout = ifelse(resgur$status == "OPTIMAL", 0, 1)
      
      MatrAloc[,idt] = c(W.best, rtime, bestD, 
                         calc.dist(dmeans, normdis='1', gamma1, gamma2), calc.dist(dmeans, normdis='2', gamma1, gamma2),
                         calc.dist(dmeans, normdis='I', gamma1, gamma2), calc.dist(dmeans, normdis='1I', gamma1, gamma2),gap)
      
      if (print.progress) print(c(ids, idt, rtime, bestD, objval))
      
      #browser()

      wini = W.best 

      idt = idt+1
    } # while (idt<=qtt)
    
    MatrAloc

  }  # foreach


  if (num*qtt==1) Stats = matrix(Stats, ncol=1)
  
  W = list()
  times = list()
  dists = list()
  distsL1 = list()
  distsL2 = list()
  distsLI = list()
  distsL1I = list()
  MipGap = list()
  for (idt in 1:qtt) {
    cols = (0:(num-1))*qtt+idt
    W[[idt]] = Stats[1:(n*ng),cols]
    times[[idt]] = Stats[(n*ng)+1,cols]
    dists[[idt]] = Stats[(n*ng)+2,cols]
    distsL1[[idt]] = Stats[(n*ng)+3,cols]
    distsL2[[idt]] = Stats[(n*ng)+4,cols]
    distsLI[[idt]] = Stats[(n*ng)+5,cols]
    distsL1I[[idt]] = Stats[(n*ng)+6,cols]
    MipGap[[idt]] = Stats[(n*ng)+7,cols]
}
  
  return(list(Stats=Stats, W=W, times=times, dists=dists, distsL1=distsL1, distsL2=distsL2, 
              distsLI=distsLI, distsL1I=distsL1I,MipGap=MipGap))

}
