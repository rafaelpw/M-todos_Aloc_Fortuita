rm(list=ls())

library(dplyr)
source('hhFunctions_gurobi.r')
source('pure_random.r')
source('genFunctions.r')

v = read.table('X.csv', header=TRUE, sep=',')
# [1] "estacao"   "MP10.chuv" "MP10.seco" "NO.chuv"   "NO.seco"   "NO2.chuv"  "NO2.seco"  "NOx.chuv"  "NOx.seco"  "O3.chuv"   "O3.seco"   "TEMP.chuv" "TEMP.seco"
# [14] "UR.chuv"   "UR.seco"   "VV.chuv"   "VV.seco"   "lat"       "long"     
qtcol = ncol(v)
x = v[,2:ncol(v)]

n = nrow(x)
#Lista de grupos
Listgr<-list()
Listgr[[1]]<-c(18,18,18)
Listgr[[2]]<-c(13,13,14,14)
Listgr[[3]]<-c(10,11,11,11,11)

# Número de simulações 
nsim = 100
normdis =  c('1I')  #'1', '2', 'I', '1I'
normdisrr = '2'
tprocs = c(300)



lambdas = c(0.001,0.05,0.1,0.2,0.3,0.4)
lambdas = c(lambdas, 1, 2)
qtlambdas = length(lambdas)
qtt = length(tprocs)

mnoise = 2   # número de counas da matriz de ru?dos

gamma1 = gamma2 = 1 


for(idg in 1:3){
  nv<-Listgr[[idg]]
  ng <- length(nv)
  
  nvstr<-paste(nv,collapse=" ")
  
  diretsai = paste0('output-',normdis,'-',nvstr,'-',tprocs,'s')
  if (!file.exists(diretsai)) {
    dir.create(diretsai)
  }
  
  ##########################
  
  # Todas as matrizes A (dos ruidos)
  MatrNoises = matrix(rnorm(mnoise*nsim*nrow(x)), ncol=nsim)  
  
  MatrNoiseStd = matrix(0,nrow=mnoise*nrow(x), ncol=nsim)    # Ru?dos normalizados
  for (ids in 1:nsim) {
    A = matrix(MatrNoises[,ids], ncol=mnoise, byrow=FALSE)
    invcholA = inverseCholCov(A)
    za = as.matrix(A) %*% invcholA
    MatrNoiseStd[,ids] = as.vector(za)
  }
  
    
  #idc=1
  for (idc in 1:qtlambdas) {
  
    lambda = lambdas[idc]
    
    print(c(idc, lambda))
  
    if (lambda<1) {
      # Funcao de chamada do Gurobi 
      Aloc = hapsamplingGurobi_Gen(x=x, lambda=lambda, ma=mnoise, num=nsim, nv=nv, NoisesStd=MatrNoiseStd,
                               normdis=normdis, gamma1=gamma1, gamma2=gamma2, tprocs=tprocs)
    } else if (lambda==1) {
      # Realeatorizacao 
      # Somente para comparacao dos resultados
      normdisrr = ifelse(normdis=='1I', '2', normdis)  
      Aloc = rerandomize.SSL(x, num=nsim, nv=nv, normdis=normdisrr, gamma1=gamma1, gamma2=gamma2, tprocs=tprocs)
    } else {
      Aloc = pureRandom(x, num=nsim, nv=nv) 
    }
  

    nmarqaloca = paste(diretsai, '/T_', normdis, '_', lambda, '.txt', sep='')
    write.table(Aloc$Stats, file=nmarqaloca, sep='\t', col.names=FALSE, row.names=FALSE)
  
    
    #browser()
  }



}


