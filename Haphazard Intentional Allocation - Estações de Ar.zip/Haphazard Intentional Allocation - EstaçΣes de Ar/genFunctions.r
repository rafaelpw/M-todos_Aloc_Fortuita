
require(psych)

source('MultiCore.r')

####### cria matriz aleat�ria de aloca��es para um vetor nv=(n1,n2,n3...n)
GenW<- function(nv){
  n<-sum(nv)
  W<-matrix(rep(0,n*length(nv)), ncol=length(nv)) #Matriz de Aloca��es
  Vac<-c()
  valoc<-seq(1:n)
  for(i in 1:length(nv)){
    valoc<-valoc[!(valoc %in% Vac)]
    VW<-sample(valoc,nv[i],replace = F)
    Vac<-c(Vac,VW)
    W[VW,i]=1}
  return(W)}
#############################




# Inversa da matriz de Covari�ncia
inverseCov = function(x) {
  CovX = cov(x)
  cholCovX = chol(CovX)
  invchol = solve(cholCovX, diag(ncol(x)), tol=.Machine$double.eps*1e-5)
  ICovX = invchol %*% t(invchol) 
  return(ICovX)  
}


# COmputa o inverso do fator de Cholesky da matriz de covari�ncia de x
inverseCholCov = function(x) {
  CovX = cov(x)
  cholCovX = chol(CovX)
  invchol = solve(cholCovX, diag(ncol(x)), tol=.Machine$double.eps*1e-5)
  return(invchol)  
}


# Forma normalizada da matriz
Std_Covariates = function (X, nt, nc) {

  invcholx = inverseCholCov(X)   
  Zx = as.matrix(X) %*% invcholx

  Rx = (nc+nt)/(nc*nt)*t(Zx)
  Sx = apply(Zx,2,sum)/nc
  
  return(list(Zx = Zx, Rx=Rx, Sx=Sx))
}

#
#  Computa a dist�ncia par cada norma

calc.dist = function(dmeans, normdis, gamma1, gamma2) {
  return(
    ifelse(normdis=='1', sum(abs(dmeans)),                # norm 1
    ifelse(normdis=='2', sqrt(t(dmeans) %*% dmeans),     # norm 2
    #ifelse(normdis=='2', t(dmeans) %*% dmeans,            # norm 2
    ifelse(normdis=='I', max(abs(dmeans)),                # norm inf
    gamma1*sum(abs(dmeans)) + gamma2*sqrt(length(dmeans))*max(abs(dmeans))))) # 1-infinity norm
  )
} 




 
# Computa a dist�ncia de Mahalanobis para cada aloca��o
#
calc.M.std = function(X, W) {
  n = nrow(X)
  n1 = sum(W[,1])
  n0 = n-n1
  
  StdCov = Std_Covariates(X, n1, n0)
  
  MahaDist = rep(0, ncol(W))
  for(jj in 1:ncol(W))
  {
    dmeans = StdCov$Rx %*% W[,jj] - StdCov$Sx
    MahaDist[jj] = calc.dist(dmeans, normdis='2')
  }
  
  return(MahaDist)
}


calc.M.std.Gen = function(X, W, nv){
    n = sum(nv)
    ng = length(nv)
    invcholx = inverseCholCov(X)   # Caution: in R, chol(X) returns an upper triangular matrix
    Zx = as.matrix(X) %*% invcholx
  
    S = rep(apply(Zx,2,sum)/n,ng)
    
    Qx = t(kronecker(diag(ng)/nv,Zx))
    
    MahaDist = rep(0, ncol(W))
    for(jj in 1:ncol(W)){
      dmeans = Qx %*% W[,jj] - S
      MahaDist[jj] = calc.dist(dmeans, normdis='2')
    }
    return(MahaDist)
}


calc.M.std.Grupos = function(X, W, nv){
  n = sum(nv)
  ng = length(nv)
  W<-as.data.frame(W)
  ng<-length(nv)
  idxc<-c(0,c(1:ng)*nrow(X)) 
  idxr<-c(0,c(1:ng)*ncol(X))
  
  invcholx = inverseCholCov(X)   # Caution: in R, chol(X) returns an upper triangular matrix
  
  Zx = as.matrix(X) %*% invcholx
  
  S = rep(apply(Zx,2,sum)/n,ng)
  
  Qx = t(kronecker(diag(ng)/nv,Zx))
  
  MahaDist = rep(0, ncol(W))
  for(jj in 1:ncol(W)){
    Mahdist_Grupo<-c()
    for(i in 1:ng){
      dmeans<-Qx[(idxr[i]+1):idxr[i+1],(idxc[i]+1):idxc[i+1]] %*% W[(idxc[i]+1):idxc[i+1],jj]-S[(idxr[i]+1):idxr[i+1]]
      Mahdist_Grupo[i]<-calc.dist(dmeans, normdis='2')
    }
    MahaDist[jj] = sum(Mahdist_Grupo)
  }
  return(MahaDist)
}


########Fun��o Coluna de �ndices
indgroup<-function(w){
  ng<-dim(w)[2]
  W.ind<-matrix(0,ncol=ncol(w),nrow=nrow(w))
  for(i in 1:ng){W.ind[,i]<-w[,i]*i}
  return(W.ind<-rowSums(W.ind))}

####Matrizes de "Avalia�oes" = Cada simula��o corresponde a um avaliador
Mkappa<-function(M,ng){
  nkv<-ncol(M)  #numero de avaliadores ou nsim
  MK<-matrix(0, nrow=nrow(M)/ng, ncol=nkv)
  for(i in 1:nkv){
    Mav<-matrix(M[,i], ncol=ng)
    MK[,i]<-indgroup(Mav)
  }
  return(MK)}


##########Fun��es Generaliza��o

####### cria matriz aleat�ria de aloca��es para um vetos nv=(n1,n2,n3...n)
GenW<- function(nv){
  n<-sum(nv)
  W<-matrix(rep(0,n*length(nv)), ncol=length(nv)) #Matriz de Aloca��es
  Vac<-c()
  valoc<-seq(1:n)
  for(i in 1:length(nv)){
    valoc<-valoc[!(valoc %in% Vac)]
    VW<-sample(valoc,nv[i],replace = F)
    Vac<-c(Vac,VW)
    W[VW,i]=1}
  return(W)}
#############################

#############Dist�ncia entre grupos 
calc.Mggrup = function(x, W, Mt, Mc) {
  Mt<-x[W==1,]
  Mc<-x[abs(W-1)==1,]
  dif<-as.vector(Mt-Mc)
  invcov<-solve(cov(x))
  Dist = t(dif)%*%invcov%*%dif
  return(Dist) 
}

###########Dist�ncia pra m�dia
calc.Mgmed = function(x,  W, xm=NULL, sigma.inv=NULL) {
  M<-x[W==1,]
  if(is.null(xm)) xm = colMeans(x)
  dif<-as.vector(colMeans(M)-xm)
  if(is.null(sigma.inv)) sigma.inv = solve(cov(x))
  Dist = t(dif)%*%sigma.inv%*%dif
  return(Dist)
}





#calcula a diferen�a entre a m�dia global e de cada aloca��o
diff.means.gen = function(x,W){
  ng<-dim(W)[2]
  difsm<-matrix(0,ncol=dim(x)[2],nrow=ng)
  for(i in 1:ng){
    M<-x[W[,i]==1,]
    difsm[i,]<-colMeans(M)-colMeans(x)
  }
  return(difsm)}




calc.diff.means = function(v,w) mean(v[w==1],na.rm=TRUE) - mean(v[w==0], na.rm=TRUE)

calc.diff.means.center = function(v,w) mean(v[w==1],na.rm=TRUE) - mean(v, na.rm=TRUE) #distancia do grupo ao dataset global

calc.diff.vars.center = function(v,w) var(v[w==1],na.rm=TRUE) - var(v, na.rm=TRUE) #distancia do grupo ao dataset global

calc.diff.means.combn.max = function(v,M){
  cbn<-combn(ncol(M),2)
  difs<-c()
  for(ii in 1:dim(cbn)[2]){
    difs[ii]<-abs(mean(v[M[,cbn[1,ii]]==1],na.rm=TRUE)-mean(v[M[,cbn[2,ii]]==1],na.rm=TRUE))
  }
  return(max(difs))
}

calc.diff.means.gen = function(v,W,ng){  #retorna uma matriz com a diferen�a entre as m�dias de cada grupo em rela��o � base total
  v<-as.data.frame(v)
  M<-matrix(W, ncol=ng)
  difs<-matrix(0,nrow=ng,ncol=ncol(v))
  for(i in 1:ng){
    difs[i,]<-colMeans(v[M[,i]==1,])-colMeans(v)
  }
  return(difs)
}
