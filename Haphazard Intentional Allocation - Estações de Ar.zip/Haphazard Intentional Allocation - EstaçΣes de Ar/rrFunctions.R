#Rotina de realeatoriza��o. (Adaptado de Kari Morgan e Marcelo Lauretto)

source('genFunctions.r')
source('MultiCore.r')


rerandomize.SSL = function(x, num=1,nv, normdis='1', gamma1=0.5, gamma2=0.5,
                           pa=NULL, a=NULL, tprocs=NULL, print.progress=TRUE)   {

  if (is.null(tprocs)) tprocs = 0
  if (is.null(a)) a = 1e+100
  if (is.null(pa)) pa = 1
  
  mintrials = round(1/pa)
  
  
  n = sum(nv)     
  ng = length(nv) 
  
  #Inversa da matriz de Cholesky
  invcholx = inverseCholCov(x)   
  z = as.matrix(x) %*% invcholx   # cov(z) =~ I

  # Matriz auxiliar para computar a dist�ncia de Mahaanobis para m�ltiplos grupos  
  Anv<-matrix(0,nrow=nrow(z)*ng,ncol=ncol(z)*ng)
  for(i in 1:ng){
    Anv[((i-1)*nrow(z)+1):(nrow(z)*i),((i-1)*ncol(z)+1):(ncol(z)*i)]<-z/nv[i]
  }
  Anv<-t(Anv)
  
  S = rep(apply(z,2,sum)/n,ng) #Vetores de valores ideais
  
  # Classificando limites de tempo
	tprocs = sort(tprocs)
	qtt = length(tprocs)

	#browser()
	
  ######## In�cio da Realeatoria��o #########
  Stats = foreach(ids=1:num, .combine=cbind, .multicombine=TRUE, .inorder=FALSE) %dopar% {
  #for(ids in 1:num) {
      
    #loop
    cur = Sys.time()
    bestD = 1e+100
    W.best = rep(0, n*ng)
    
    # MatrAloc � uma matriz auxiliar. 
    # As colunas s�o organizadas como segue:
    #   1..n : vetor de aloca��es
    #   n+1 : tempo de processamento
    #   n+2 : dist�ncia m�nima
    #   n+3 : quantidade de ensaios
    #   n+4 : dist�ncia na norma L1 
    #   n+5 : dist�ncia na norma L2 
    #   n+6 : dist�ncia na norma Linf 
    #   n+7 : dist�ncia na norma h�brida
	  MatrAloc = matrix(0, nrow=(n*ng)+7, ncol=qtt)
	  
	  idt = 1
	  trial = as.double(0.0)
	  while (idt<=qtt) {
      tprocatu = tprocs[idt]

		  accept = FALSE
		  while(!accept) {
		    trial = trial+1
		    W.temp = as.vector(GenW(nv)) # vetor de aloca��o aleat�rio para n*ng aloca��es
		    
		    dmeans = Anv %*% W.temp - S

		    # computando as dist�ncias 
		    cur.dist = calc.dist(dmeans, normdis, gamma1, gamma2)

		    
		    if (cur.dist<bestD) {
		      bestD = cur.dist
		      W.best = W.temp
		      }
		    
		    rtime = as.numeric(difftime(Sys.time(), cur, units='secs'))
		    #### crit�rio de balanceamento ####
		    accept = (bestD <= a & rtime >= tprocatu & trial>=mintrials)
		  
		  }  # while(!accept)

		  if(print.progress) print(c(ids, bestD, rtime))
		  
		  dmeans = Anv %*% W.best - S
		  MatrAloc[,idt] = c(W.best, rtime, bestD, trial,
		                     calc.dist(dmeans, normdis='1', gamma1, gamma2), calc.dist(dmeans, normdis='2', gamma1, gamma2),
		                     calc.dist(dmeans, normdis='I', gamma1, gamma2), calc.dist(dmeans, normdis='1I', gamma1, gamma2))
		  idt = idt+1
		  
		  
		} # while (idt<=qtt)
	  
	  MatrAloc
 
  } # foreach(ids=1:num, .combine=cbind, .multicombine=TRUE, .inorder=FALSE)
  
  if (num*qtt==1) Stats = matrix(Stats, ncol=1)

	W = list()
	times = list()
	dists = list()
	trials = list()
	distsL1 = list()
	distsL2 = list()
	distsLI = list()
	distsL1I = list()
	
	for (idt in 1:qtt) {
	  cols = (0:(num-1))*qtt+idt
	  W[[idt]] = Stats[1:((n*ng)),cols]
	  times[[idt]] = Stats[(n*ng)+1,cols]
	  dists[[idt]] = Stats[(n*ng)+2,cols]
	  trials[[idt]] = Stats[(n*ng)+3,cols]
	  distsL1[[idt]] = Stats[(n*ng)+4,cols]
	  distsL2[[idt]] = Stats[(n*ng)+5,cols]
	  distsLI[[idt]] = Stats[(n*ng)+6,cols]
	  distsL1I[[idt]] = Stats[(n*ng)+7,cols]
	}

  return(list(Stats=Stats, W=W, times=times, dists=dists, trials=trials, distsL1=distsL1, distsL2=distsL2, 
              distsLI=distsLI, distsL1I=distsL1I))
}

